invitados = ["Ana","Sofia","Sofi"]
nombre = input("Ingrese su nombre: \n")

if nombre in invitados:
    print("Estas en la lista")
else:
    print("Lo siento, no estas en la lista")
