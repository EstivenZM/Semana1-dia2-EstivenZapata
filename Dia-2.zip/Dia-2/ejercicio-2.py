lista = [1,2,3,4,5]
num=int(input("Ingrese un numero: \n"))


if num in lista:
    print("El numero si esta en la lista")
else:
    print("El numero no esta en la lista")
