edad = int(input("Ingrese su edad: \n"))

if edad<0 or edad>120:
    print("Edad no valida")
else:
    print("Edad válida")