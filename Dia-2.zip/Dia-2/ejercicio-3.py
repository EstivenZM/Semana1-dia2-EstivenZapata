nombres = []
nombreusuario=input("Ingrese su nombre: \n")

#Para agregar a una lista, llamamos la lista y la funcion append()
nombres.append(nombreusuario)

print("Su nombre es: ",nombres)
