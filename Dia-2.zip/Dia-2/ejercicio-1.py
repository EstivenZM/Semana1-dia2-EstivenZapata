num1 = float(input("Ingrese el 1er numero: \n"))
num2 = float(input("Ingrese el 2do numero: \n"))
num3 = float(input("Ingrese el 3er numero: \n"))

if num1 < num2 and num1 < num3:
    print("El numero ",num1," es el mas pequeño")
elif num2 < num1 and num2 < num3:
    print("El numero ",num2," es el mas pequeño")
else:
    print("El numero ",num3," es el mas pequeño")